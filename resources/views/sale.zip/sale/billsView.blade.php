

   @extends('layouts.mast')
   @section('content')
   @include('sale.commonFormHeader');
              <div class="col-md-10" id="mainbody" style="left: 17%; top: 19%; position: fixed;">
                <div class="row col-md-12 change"  style="height: 440px; overflow-y: scroll;">
                  <style>
                  .form-group{
                    margin: 5px;
                  }
                  .form-control{
                    height:25px;
                  }
                  .col-in{
                    margin:5px;
                    padding: 0;
                  }
                  </style>
                    <!--col -->
                    <div class="title" style="z-index:1; position:fixed; width:80%" >
                     <pre style="background:#09649a !important; color:white;">   View Bills </pre>
                     </div>
                        <div class="white-box" style=" height: 440px; padding:0 !important; margin-top: 40px;">
                            <div class="col-in row">
                               <div class="col-md-12">
                                 <div class="box container box-success" style="border-top-color: #efefef"><br>

                                     <a href="home" class="btn btn-success btn-xs">Back to Dashboard</a><br><br>
                                       <div class="box-body">
                                          <!-- 
                                           -->
                                     </div>

                                 </div>

                            </div>
                        </div>
                    </div>
                    <!-- /.col -->
                </div>


            </div>



            <script type="application/javascript">

$("#treeview").hummingbird();
$(".documents").click(function(e) {
        e.preventDefault();
        var url = $(this).attr("href");
        $("#mainbody").load(url);
    });
</script>

@endsection
