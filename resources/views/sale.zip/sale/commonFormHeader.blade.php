
   <div id="wrapper">
        <!-- Navigation -->

        <!-- Page Content -->
        <div class="navbar-static-top" id="wrapper" style="    top: 10%;
    overflow: hidden;
    position: fixed;
    z-index: 0;">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Sales <small>ITEMS</small></h4> </div>
                        <div class="col-lg-6 col-md-6 col-sm-4 col-xs-12">

                        </div>
                        <ol class="breadcrumb">
                            <li><a href="#">Sales</a></li>
                            <li class="active"><a href="#">Bike </a></li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
</div>
                <!-- row -->
                <div id="page-wrapper">
                  <div class=" panel left-panel cf col-md-2" style="margin: 0px; left: 0%; top: 19%; position: fixed;">
                      <div class="pull-right col-md-12" style="padding: 0px; height: 440px;">
                      <div class="title" style="position:fixed; width: 16%; z-index:1;">
                       <pre style="background:#09649a !important; color:white">     OPERATIONS    </pre>
                       </div>
                      <div class="white-box" style="height:440px; padding: 15px 3px 3px 3px !important; z-index:0;">

                        <style>
                        /* Style the tab */
                        div.tab {
                            overflow: hidden;
                            border: 1px solid #ccc;
                            background-color: #f1f1f1;
                            margin-top: 9%;
                        }

                        /* Style the buttons inside the tab */
                        div.tab button {
                            background-color: inherit;
                            float: left;
                            border: none;
                            outline: none;
                            cursor: pointer;
                            padding: 14px 16px;
                            transition: 0.3s;
                            font-size: 14px;
                            padding: 5px;
                        }

                        /* Change background color of buttons on hover */
                        div.tab button:hover {
                            background-color: #ddd;
                        }

                        /* Create an active/current tablink class */
                        div.tab button.active {
                            background-color: #ccc;
                        }

                        /* Style the tab content */
                        .tabcontent {
                            display: none;
                            padding: 6px 12px;
                            border: 1px solid #ccc;
                            border-top: none;
                        }
						ul, li{
							list-style-type: none;
						}
						li:hover{
							cursor:pointer;
						}
                        </style>
						<div class="services" style="margin-top:16%">

						<ul id="treeview" style="">

      <li> <i class="fa fa-plus"></i>
    <label>
      <i class="fa fa-folder" style="color:rgba(237, 166, 90, 1);"></i>
      View Sales </label>
    <ul>
      <li>
        <label>
          <i class="fa fa-file"style="color:rgba(237, 166, 90, 1);"></i>
          <a  href="sale">Bikes </a></label>


      </li>


      <li>
        <label>
          <i class="fa fa-file"style="color:rgba(237, 166, 90, 1);"></i>
          <a  href="saleparts"> Parts </a></label>

      </li>
    </ul>
  </li>

  <li> <i class="fa fa-plus"></i>

      <i class="fa fa-folder" style="color:rgba(237, 166, 90, 1);"></i>
	   <a class="button documents" href="billView" >View Bills</a>
 <div>
            <br clear="change" />
        </div>


  </li>
</ul>


						</div>


                  </div>
                </div>
              </div>
               <div class="col-md-10" id="mainbody" style="left: 17%; top: 19%; position: fixed;">
                <div class="row col-md-12 change"  style="height: 440px; overflow-y: scroll;">
                  <style>
                  .form-group{
                    margin: 5px;
                  }
                  .form-control{
                    height:25px;
                  }
                  .col-in{
                    margin:5px;
                    padding: 0;
                  }
                  </style>
                    <!--col -->
                    <div class="title" style="z-index:1; position:fixed; width:80%" >
                     <pre style="background:#09649a !important; color:white;">   ITEMS INFORMATION </pre>
                     </div>
                        <div class="white-box" style=" height: 440px; padding:0 !important; margin-top: 40px;">
                            <div class="col-in row">
                               <div class="col-md-12">
                                 <div class="tab" style="margin:0 !important;">
                                   <ul id="myTab" class="nav nav-tabs">
                                          <li class="active"><a href="#home" data-target="#home, #home_else" data-toggle="tab">Bikes</a></li>
                                          <li><a href="#profile" data-target="#profile, #profile_else" data-toggle="tab">Parts</a></li>
                                          <!-- <li><a href="#bikeupdate" data-target="#bikeupdate" data-toggle="tab">Bike Update</a></li> -->
                                      </ul>

                                     </div>




                                <div id="myTabContent" class="tab-content">
                                    <div class="tab-pane fade in active" id="bike_bills">
                                      <h4>Import File Directly:</h4>
                                      <table width= 100%  style="border: 0px !important">
                                        <tr  >
                                          <td  style="border: 0px !important" >
                                        <a href="{{ asset('resources/demobikestock.ods') }}" > See Demo </a>
                                      </td>
                                      <td  style="border: 0px !important" >

                                      <form style="border: 1px solid #a1a1a1;margin-top: 3px;padding: 10px;" action="{{ URL::to('importExcelBike') }}" class="form-horizontal" method="post" enctype="multipart/form-data">

                                        <input type="file" name="import_file" style="margin: 0;    display: inline-block;
                                  margin-top: -12px;
                                  padding: 0;
                                  height: 20px;" />
                                        {{ csrf_field() }}


                                        <button class="btn btn-primary" style="    display: inline-block;">Import CSV or Excel File</button>

                                      </form>
                                    </td>
                                  </tr>
                                    </table>
                                     <div class="box container box-success " style="border-top-color: #efefef">
          <div class="box-body">
              <table id="example1" class="display compact table-bordered table-striped" cellspacing="0" width="100%">
                <thead>
                <tr>


                  <th>Bike Model</th>
                  <th>Stock Remains</th>


                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                    <tr>

                    <td></td>
                    <td></td>

                    <td><div class="col-sm-2">
                      <a  href=""><button class="btn btn-info btn-xs">Edit</button></a>
                    </div>
                    <div class="col-sm-2">
  
                       <!--  -->
                          </div>

                        </td>


                    </tr>

                  </tbody>
              </table>
        </div>

    </div>
                                    </div>
                                    <div class="tab-pane fade" id="parts_bill">
                                      <h4>Import File Directly:</h4>
                                      <table width= 100%  style="border: 0px !important">
                                        <tr  >
                                          <td  style="border: 0px !important" >
                                        <a href="{{ asset('resources/demopartsstock.ods') }}" > See Demo </a>
                                      </td>
                                      <td  style="border: 0px !important" >

                                      <form style="border: 1px solid #a1a1a1;margin-top: 3px;padding: 10px;" action="{{ URL::to('importExcelPart') }}" class="form-horizontal" method="post" enctype="multipart/form-data">

                                        <input type="file" name="import_file" style="margin: 0;    display: inline-block;
                                      margin-top: -12px;
                                      padding: 0;
                                      height: 20px;" />
                                        {{ csrf_field() }}


                                        <button class="btn btn-primary" style="    display: inline-block;">Import CSV or Excel File</button>

                                      </form>
                                      </td>
                                      </tr>
                                      </table>
                                      <div class="box container box-success " style="border-top-color: #efefef">
                                            <div class="box-body">
              <table id="example3" class="display compact table-bordered table-striped" cellspacing="0" width="100%">
                <thead>
                <tr>


                  <th>Parts Model</th>
                  <th>Bike Model</th>
                  <th>Stock</th>
                  <th>Created At</th>

                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                    <tr>

                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>

                        <td> <div class="col-sm-3">
                            <a  href="#"><button class="btn btn-info btn-xs">Edit</button></a>
                          </div>
                          <div class="col-sm-2">
                      
                        </td>


                    </tr>
                  
                  </tbody>
              </table>
        </div>

    </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- /.col -->
                </div>


            </div>
  <script type="application/javascript">
            $(document).ready(function(){

              document.getElementById("Bikes").style.display = "block";
              evt.currentTarget.className += " active";
            });

$("#treeview").hummingbird();
$(".documents").click(function(e) {
        e.preventDefault();
        var url = $(this).attr("href");
        $("#mainbody").load(url);
    });
</script>
